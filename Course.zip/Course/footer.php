<footer id="footer">
<p>Education Shopper 2021 &copy;, ALL Rights Reserved </p>
        

    </footer> 