                <div class="sidebar-inner slimscrollleft">
                    <div class="user-details">
                        <div class="pull-left">
                            <img src="../img/sk1.jpg" alt="" class="thumb-md img-circle">
                        </div>
                        <div class="user-info">
                            <div class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Shahriar Shaikat </span></a>
                                
                            </div>
                            
                            <p class="text-muted m-0">Administrator</p>
                        </div>
                    </div>
                    <!--- Divider -->
                    <div id="sidebar-menu">
                        <ul>
                            <li>
                                <a href="http://localhost/Course/Admin/Dashboard.php" class="waves-effect"><i class="md md-home"></i><span> Dashboard </span></a>
                            </li>

                            <li class="has_sub">
                                <a href="#" class="waves-effect"><i class="fa fa-book"></i><span> Course </span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="http://localhost/course/Admin/addCourse.php">Add Course</a></li>
                                    <li><a href="http://localhost/course/Admin/viewCourse.php">View Course</a></li>
                                </ul>
                            </li>

                            <li>
                                <a href="coupon.php" class="waves-effect"><i class="fa fa-file-code-o"></i><span>Coupon</span></a>
                            </li>

                            <li>
                                <a href="../logout.php" class="waves-effect"><i class="fa fa-sign-out"></i><span> Log Out </span></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="clearfix"></div>
                </div>